package java_collection_framework.install_bst;

public abstract class AbstractTree<E> implements Tree<E>{
    @Override /** Inorder traversal from the root*/
    public void inorder() {
    }
}
